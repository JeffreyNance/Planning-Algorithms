package edu.uky.ai.planning.ex;

import edu.uky.ai.SearchBudget;
import edu.uky.ai.planning.ss.ForwardPlanner;
import edu.uky.ai.planning.ss.StateSpaceProblem;

/**
 * A state-space planner that performs a simple HSP through the
 * space of possible states.
 * 
 * @author Jeffrey E. Nance
 */
public class MyHSPPlanner extends ForwardPlanner {

	/**
	 * Constructs a new HSP planner.
	 */
	public MyHSPPlanner() {
		super("jena227-HSP");
	}

	@Override
	protected MyHSP makeForwardSearch(StateSpaceProblem problem, SearchBudget budget) {
		// Create and return a search object for the given problem using the
		// given search budget.
		return new MyHSP(problem, budget);
	}
}
package edu.uky.ai.planning.ex;

import java.util.LinkedList;
import java.util.Queue;

import edu.uky.ai.SearchBudget;
import edu.uky.ai.logic.HashState;
import edu.uky.ai.logic.MutableState;
import edu.uky.ai.planning.Plan;
import edu.uky.ai.planning.Step;
import edu.uky.ai.planning.ss.ForwardNode;
import edu.uky.ai.planning.ss.ForwardSearch;
import edu.uky.ai.planning.ss.StateSpaceProblem;
import edu.uky.ai.util.MinPriorityQueue;
import edu.uky.ai.logic.Literal;
import edu.uky.ai.logic.Atom;
import edu.uky.ai.logic.NegatedAtom;
import java.util.Map;
import java.util.HashMap;

/**
 * A breadth-first search through the space of possible states.
 * 
 * @author Jeffrey E. Nance
 */
public class MyHSP extends ForwardSearch {
	
	/** The queue where search nodes will be stored */
	protected final MinPriorityQueue<ForwardNode> MinQueue = new MinPriorityQueue<>();
	
	/**
	 * Constructs and initializes a new search for a given problem.
	 * 
	 * @param problem the state-space problem this search will solve
	 * @param budget the budget that limits this search
	 */
	public MyHSP(StateSpaceProblem problem, SearchBudget budget) {
		super(problem, budget);
		// Add the root node of the search to the queue.
		MinQueue.push(root, 0);
	}
	
	@Override
	public Plan solve() {

		// Run until there are no more nodes left in the queue.
		while (!MinQueue.isEmpty()) {
			// Pop the first node off the queue.
			ForwardNode node = MinQueue.pop();

			// Check the node's state to see if the goal is satisfied. If so,
			// return the node's plan as a solution.
			if (problem.goal.isTrue(node.state)) {
				return node.plan;
			}

			// Check every ground step in the problem...
			for (Step step : problem.steps) {
				// If the step's precondition is satisfied in the node's state...
				if (step.precondition.isTrue(node.state)) {
					// Create a new state that is the same as the node's state.
					MutableState child = new HashState(node.state);

					// Apply the effects of the step being taken.
					step.effect.makeTrue(child);

					// Create the child node and push it onto the queue.
					ForwardNode ChildNode = node.expand(step, child);
					MinQueue.push(ChildNode, node.plan.size() + 1 + 5 * Heuristic(ChildNode));
				}
			}
		}
		// If the queue is empty, fail.
		return null;
	}

	public double Heuristic(ForwardNode node) {
		//Loop Through All The Problem's Literals
		Map<Literal, Integer> LiteralCosts = new HashMap<>();
		Map<Literal, Integer> OriginalLiteralCosts = new HashMap<>();
		for (Literal literal : problem.literals) {
			//Initially, Literals Which Show up Have Zero Cost
			if (literal.isTrue(node.state)) {
				LiteralCosts.put(literal, 0);
			}

			//Initially, Literals Which do Not Show up Have Infinite Cost
			else {
				LiteralCosts.put(literal, 9999999);
			}
		}

		//Loop Until The Costs do Not Change
		int PreconditionsPlus;
		String Preconditions;
		String Effects;
		do {
			OriginalLiteralCosts = new HashMap<>(LiteralCosts);
			//Loop Through Each Step in The Problem
			for (Step step : problem.steps) {
				//Find The Minimum Cost For Reaching The Literal
				PreconditionsPlus = 1;
				Preconditions = step.precondition.toString();
				Effects = step.effect.toString();
				for (Literal literal : problem.literals) {
					if (Preconditions.contains(literal.toString())) {
						PreconditionsPlus += LiteralCosts.get(literal);
					}
				}

				for (Literal literal : problem.literals) {
					if (Effects.contains(literal.toString()) && PreconditionsPlus < LiteralCosts.get(literal)) {
						LiteralCosts.put(literal, PreconditionsPlus);
					}
				}
			}
		} while (!OriginalLiteralCosts.equals(LiteralCosts));

		//Get The Heuristic Value of The State
		double Heuristic = 0;
		String Goals = problem.goal.toString();
		for (Literal literal : problem.literals) {
			if (Goals.contains(literal.toString())) {
				Heuristic += LiteralCosts.get(literal);
			}
		}

		return Heuristic;
	}
}